<?php
session_start();

$host = 'localhost';
$username = 'root';
$password = '';
$database = 'contact_book';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit();
    }
}

function redirectIfLoggedIn() {
    if (isLoggedIn()) {
        header('Location: dashboard.php');
        exit();
    }
}

function getCurrentUser() {
    global $pdo;
    if (isLoggedIn()) {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch();
            
            if (!$user) {
                // Jika user tidak ditemukan, hapus session
                session_unset();
                session_destroy();
                return null;
            }
            
            return $user;
        } catch (PDOException $e) {
            // Jika ada error database, hapus session
            session_unset();
            session_destroy();
            return null;
        }
    }
    return null;
}

function sanitizeInput($input) {
    return htmlspecialchars(trim($input));
}

function getStatusBadge($status) {
    switch($status) {
        case 'Aktif':
            return '<span class="badge bg-success">Aktif</span>';
        case 'Pasif':
            return '<span class="badge bg-secondary">Pasif</span>';
        case 'Diblokir':
            return '<span class="badge bg-danger">Diblokir</span>';
        default:
            return '<span class="badge bg-secondary">' . $status . '</span>';
    }
}

function getCategoryBadge($category, $color = null) {
    if ($color) {
        return '<span class="badge" style="background-color: ' . $color . '; color: white;">' . htmlspecialchars($category) . '</span>';
    }
    
    // Default colors for legacy categories
    switch($category) {
        case 'Klien':
            return '<span class="badge bg-primary">Klien</span>';
        case 'Tim Support':
            return '<span class="badge bg-info">Tim Support</span>';
        case 'Vendor':
            return '<span class="badge bg-warning text-dark">Vendor</span>';
        case 'Partner':
            return '<span class="badge bg-success">Partner</span>';
        default:
            return '<span class="badge bg-secondary">' . htmlspecialchars($category) . '</span>';
    }
}

function getUserCategories($user_id) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT name, color FROM categories WHERE user_id = ? ORDER BY name ASC");
        $stmt->execute([$user_id]);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        return [];
    }
}

function addUserCategory($user_id, $name, $color = '#6c757d') {
    global $pdo;
    try {
        $stmt = $pdo->prepare("INSERT INTO categories (user_id, name, color) VALUES (?, ?, ?)");
        $stmt->execute([$user_id, $name, $color]);
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

function deleteUserCategory($user_id, $category_name) {
    global $pdo;
    try {
        // Cek apakah ada kontak yang menggunakan kategori ini
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM contacts WHERE user_id = ? AND category = ?");
        $stmt->execute([$user_id, $category_name]);
        $count = $stmt->fetchColumn();
        
        if ($count > 0) {
            return false; // Tidak bisa dihapus karena masih digunakan
        }
        
        $stmt = $pdo->prepare("DELETE FROM categories WHERE user_id = ? AND name = ?");
        $stmt->execute([$user_id, $category_name]);
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

function getCategoryColor($user_id, $category_name) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT color FROM categories WHERE user_id = ? AND name = ?");
        $stmt->execute([$user_id, $category_name]);
        $result = $stmt->fetch();
        return $result ? $result['color'] : null;
    } catch (PDOException $e) {
        return null;
    }
}
?> 