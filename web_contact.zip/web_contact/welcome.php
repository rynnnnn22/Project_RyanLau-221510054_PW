<?php
require_once 'includes/config.php';
redirectIfLoggedIn();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Selamat Datang - Contact Book</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="welcome-container">
        <div class="welcome-header">
            <h1><i class="bi bi-person-rolodex"></i> Contact Book</h1>
            <p class="lead">Kelola semua kontak Anda dengan mudah dan terorganisir</p>
        </div>
        
        <div class="welcome-buttons">
            <a href="login.php" class="btn-custom btn-primary-custom">
                <i class="bi bi-box-arrow-in-right"></i> Login
            </a>
            <a href="register.php" class="btn-custom btn-outline-custom">
                <i class="bi bi-person-plus"></i> Daftar
            </a>
        </div>
        
        <div class="mt-5 text-white text-center">
            <h5>Fitur Unggulan</h5>
            <div class="row mt-4">
                <div class="col-md-4">
                    <i class="bi bi-search display-6"></i>
                    <h6 class="mt-2">Pencarian Cepat</h6>
                    <small>Cari kontak berdasarkan nama, email, atau telepon</small>
                </div>
                <div class="col-md-4">
                    <i class="bi bi-tags display-6"></i>
                    <h6 class="mt-2">Kategori & Filter</h6>
                    <small>Organisir kontak dengan kategori dan status</small>
                </div>
                <div class="col-md-4">
                    <i class="bi bi-phone display-6"></i>
                    <h6 class="mt-2">Responsif</h6>
                    <small>Akses dari desktop maupun mobile</small>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html> 