<?php
require_once 'includes/config.php';
requireLogin();

$search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';
$status_filter = isset($_GET['status']) ? sanitizeInput($_GET['status']) : '';
$category_filter = isset($_GET['category']) ? sanitizeInput($_GET['category']) : '';

$where_conditions = ['user_id = ?'];
$params = [$_SESSION['user_id']];

if (!empty($search)) {
    $where_conditions[] = '(name LIKE ? OR email LIKE ? OR phone LIKE ?)';
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

if (!empty($status_filter)) {
    $where_conditions[] = 'status = ?';
    $params[] = $status_filter;
}

if (!empty($category_filter)) {
    $where_conditions[] = 'category = ?';
    $params[] = $category_filter;
}

$where_clause = implode(' AND ', $where_conditions);

try {
    $stmt = $pdo->prepare("SELECT * FROM contacts WHERE $where_clause ORDER BY created_at DESC");
    $stmt->execute($params);
    $contacts = $stmt->fetchAll();

    $stats_stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'Aktif' THEN 1 ELSE 0 END) as aktif,
            SUM(CASE WHEN status = 'Pasif' THEN 1 ELSE 0 END) as pasif,
            SUM(CASE WHEN status = 'Diblokir' THEN 1 ELSE 0 END) as diblokir
        FROM contacts WHERE user_id = ?
    ");
    $stats_stmt->execute([$_SESSION['user_id']]);
    $stats_result = $stats_stmt->fetch();
    
    if ($stats_result) {
        $stats = [
            'total' => (int)$stats_result['total'],
            'aktif' => (int)($stats_result['aktif'] ?: 0),
            'pasif' => (int)($stats_result['pasif'] ?: 0),
            'diblokir' => (int)($stats_result['diblokir'] ?: 0)
        ];
    } else {
        $stats = ['total' => 0, 'aktif' => 0, 'pasif' => 0, 'diblokir' => 0];
    }
} catch (PDOException $e) {
    $contacts = [];
    $stats = ['total' => 0, 'aktif' => 0, 'pasif' => 0, 'diblokir' => 0];
}

$current_user = getCurrentUser();
$user_categories = getUserCategories($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Contact Book</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="dashboard-body">
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-person-rolodex"></i>Contact Book
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="add_contact.php">
                            <i class="bi bi-person-plus"></i> Tambah Kontak
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_categories.php">
                            <i class="bi bi-tags"></i> Kelola Kategori
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle"></i> <?= htmlspecialchars($current_user['username'] ?? 'User') ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container main-content">
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-<?= $_SESSION['message_type'] === 'success' ? 'success' : 'danger' ?> alert-dismissible fade show">
                <?= $_SESSION['message'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php 
            unset($_SESSION['message']);
            unset($_SESSION['message_type']);
            ?>
        <?php endif; ?>

        <div class="dashboard-header">
            <h2>Dashboard Kontak</h2>
            <p class="text-muted">Kelola semua kontak Anda dengan mudah</p>
        </div>

        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-number"><?= $stats['total'] ?></div>
                <div class="stat-label">Total Kontak</div>
            </div>
            <div class="stat-card">
                <div class="stat-number text-success"><?= $stats['aktif'] ?></div>
                <div class="stat-label">Aktif</div>
            </div>
            <div class="stat-card">
                <div class="stat-number text-secondary"><?= $stats['pasif'] ?></div>
                <div class="stat-label">Pasif</div>
            </div>
            <div class="stat-card">
                <div class="stat-number text-danger"><?= $stats['diblokir'] ?></div>
                <div class="stat-label">Diblokir</div>
            </div>
        </div>

        <div class="contacts-card">
            <div class="card-header-custom d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="bi bi-people"></i> Daftar Kontak</h5>
                <a href="add_contact.php" class="btn btn-light">
                    <i class="bi bi-plus-circle"></i> Tambah Kontak
                </a>
            </div>

            <div class="search-filter-container">
                <form method="GET" class="search-filter-row">
                    <input type="text" class="form-control" id="search" name="search" 
                           placeholder="Cari kontak (nama, email, telepon)..." value="<?= htmlspecialchars($search) ?>">
                    
                    <select class="form-select" id="status-filter" name="status" style="width: auto;">
                        <option value="">Semua Status</option>
                        <option value="Aktif" <?= $status_filter === 'Aktif' ? 'selected' : '' ?>>Aktif</option>
                        <option value="Pasif" <?= $status_filter === 'Pasif' ? 'selected' : '' ?>>Pasif</option>
                        <option value="Diblokir" <?= $status_filter === 'Diblokir' ? 'selected' : '' ?>>Diblokir</option>
                    </select>
                    
                    <select class="form-select" id="category-filter" name="category" style="width: auto;">
                        <option value="">Semua Kategori</option>
                        <?php foreach ($user_categories as $cat): ?>
                            <option value="<?= htmlspecialchars($cat['name']) ?>" 
                                    <?= $category_filter === $cat['name'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cat['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-search"></i> Cari
                    </button>
                </form>
            </div>

            <div class="table-container">
                <table class="table table-custom" id="contacts-table">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Telepon</th>
                            <th>Status</th>
                            <th>Kategori</th>
                            <th>Catatan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($contacts)): ?>
                            <tr>
                                <td colspan="7" class="empty-state">
                                    <i class="bi bi-people"></i>
                                    <h5>Belum ada kontak</h5>
                                    <p>Mulai tambahkan kontak pertama Anda</p>
                                    <a href="add_contact.php" class="btn btn-primary mt-2">
                                        <i class="bi bi-plus-circle"></i> Tambah Kontak
                                    </a>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($contacts as $contact): ?>
                                <tr>
                                    <td class="fw-bold"><?= htmlspecialchars($contact['name']) ?></td>
                                    <td>
                                        <?php if ($contact['email']): ?>
                                            <a href="mailto:<?= htmlspecialchars($contact['email']) ?>">
                                                <?= htmlspecialchars($contact['email']) ?>
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($contact['phone']): ?>
                                            <a href="tel:<?= htmlspecialchars($contact['phone']) ?>">
                                                <?= htmlspecialchars($contact['phone']) ?>
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= getStatusBadge($contact['status']) ?></td>
                                    <td><?= getCategoryBadge($contact['category'], getCategoryColor($_SESSION['user_id'], $contact['category'])) ?></td>
                                    <td>
                                        <?php if ($contact['notes']): ?>
                                            <span class="text-truncate d-inline-block" style="max-width: 150px;" title="<?= htmlspecialchars($contact['notes']) ?>">
                                                <?= htmlspecialchars($contact['notes']) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="edit_contact.php?id=<?= $contact['id'] ?>" class="btn btn-outline-primary btn-action">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <a href="delete_contact.php?id=<?= $contact['id'] ?>" class="btn btn-outline-danger btn-action btn-delete">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html> 