<?php
require_once 'includes/config.php';
requireLogin();

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: dashboard.php');
    exit();
}

$contact_id = (int)$_GET['id'];

try {
    $stmt = $pdo->prepare("SELECT name FROM contacts WHERE id = ? AND user_id = ?");
    $stmt->execute([$contact_id, $_SESSION['user_id']]);
    $contact = $stmt->fetch();
    
    if (!$contact) {
        $_SESSION['message'] = 'Kontak tidak ditemukan';
        $_SESSION['message_type'] = 'error';
        header('Location: dashboard.php');
        exit();
    }
    
    $delete_stmt = $pdo->prepare("DELETE FROM contacts WHERE id = ? AND user_id = ?");
    $delete_stmt->execute([$contact_id, $_SESSION['user_id']]);
    
    $_SESSION['message'] = 'Kontak "' . htmlspecialchars($contact['name']) . '" berhasil dihapus';
    $_SESSION['message_type'] = 'success';
    
} catch (PDOException $e) {
    $_SESSION['message'] = 'Terjadi kesalahan saat menghapus kontak';
    $_SESSION['message_type'] = 'error';
}

header('Location: dashboard.php');
exit();
?> 