<?php
require_once 'includes/config.php';
requireLogin();

$error = '';
$success = '';

// Handle add category
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    $name = sanitizeInput($_POST['name']);
    $color = sanitizeInput($_POST['color']);
    
    if (empty($name)) {
        $error = 'Nama kategori harus diisi';
    } else {
        if (addUserCategory($_SESSION['user_id'], $name, $color)) {
            $success = 'Kategori berhasil ditambahkan';
        } else {
            $error = 'Kategori sudah ada atau terjadi kesalahan';
        }
    }
}

// Handle delete category
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'delete') {
    $category_name = sanitizeInput($_POST['category_name']);
    
    if (deleteUserCategory($_SESSION['user_id'], $category_name)) {
        $success = 'Kategori berhasil dihapus';
    } else {
        $error = 'Kategori tidak bisa dihapus karena masih digunakan atau terjadi kesalahan';
    }
}

$categories = getUserCategories($_SESSION['user_id']);
$current_user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Kategori - Contact Book</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="dashboard-body">
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-person-rolodex"></i>Contact Book
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="add_contact.php">
                            <i class="bi bi-person-plus"></i> Tambah Kontak
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="manage_categories.php">
                            <i class="bi bi-tags"></i> Kelola Kategori
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle"></i> <?= htmlspecialchars($current_user['username'] ?? 'User') ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container main-content">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="contact-form">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h2><i class="bi bi-tags"></i> Kelola Kategori</h2>
                        <a href="dashboard.php" class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-left"></i> Kembali
                        </a>
                    </div>

                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-custom"><?= $error ?></div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert alert-success alert-custom"><?= $success ?></div>
                    <?php endif; ?>

                    <!-- Form Tambah Kategori -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="bi bi-plus-circle"></i> Tambah Kategori Baru</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="action" value="add">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="name" class="form-label">Nama Kategori</label>
                                            <input type="text" class="form-control" id="name" name="name" required placeholder="Contoh: Customer, Supplier">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="color" class="form-label">Warna Badge</label>
                                            <input type="color" class="form-control form-control-color" id="color" name="color" value="#6c757d">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="form-label">&nbsp;</label>
                                            <button type="submit" class="btn btn-primary w-100">
                                                <i class="bi bi-plus"></i> Tambah
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Daftar Kategori -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="bi bi-list"></i> Daftar Kategori</h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($categories)): ?>
                                <div class="text-center py-4">
                                    <i class="bi bi-tags display-4 text-muted"></i>
                                    <h5 class="mt-3 text-muted">Belum ada kategori</h5>
                                    <p class="text-muted">Tambahkan kategori pertama Anda di atas</p>
                                </div>
                            <?php else: ?>
                                <div class="row">
                                    <?php foreach ($categories as $category): ?>
                                        <div class="col-md-6 mb-3">
                                            <div class="card border">
                                                <div class="card-body d-flex justify-content-between align-items-center">
                                                    <div class="d-flex align-items-center">
                                                        <span class="badge me-3" style="background-color: <?= htmlspecialchars($category['color']) ?>; color: white; font-size: 0.9rem; padding: 0.5rem 1rem;">
                                                            <?= htmlspecialchars($category['name']) ?>
                                                        </span>
                                                        <small class="text-muted"><?= htmlspecialchars($category['color']) ?></small>
                                                    </div>
                                                    <form method="POST" class="d-inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus kategori ini?')">
                                                        <input type="hidden" name="action" value="delete">
                                                        <input type="hidden" name="category_name" value="<?= htmlspecialchars($category['name']) ?>">
                                                        <button type="submit" class="btn btn-outline-danger btn-sm">
                                                            <i class="bi bi-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="mt-4 alert alert-info">
                        <h6><i class="bi bi-info-circle"></i> Informasi:</h6>
                        <ul class="mb-0">
                            <li>Kategori yang sudah digunakan pada kontak tidak bisa dihapus</li>
                            <li>Pilih warna yang berbeda untuk setiap kategori agar mudah dibedakan</li>
                            <li>Nama kategori harus unik per user</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html> 