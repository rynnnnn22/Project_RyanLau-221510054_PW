<?php
require_once 'includes/config.php';
requireLogin();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = sanitizeInput($_POST['name']);
    $email = sanitizeInput($_POST['email']);
    $phone = sanitizeInput($_POST['phone']);
    $status = sanitizeInput($_POST['status']);
    $category = sanitizeInput($_POST['category']);
    $notes = sanitizeInput($_POST['notes']);

    if (empty($name) || empty($category)) {
        $error = 'Nama dan kategori harus diisi';
    } elseif (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid';
    } elseif (!in_array($status, ['Aktif', 'Pasif', 'Diblokir'])) {
        $error = 'Status tidak valid';
    } else {
        // Validasi kategori exists untuk user ini
        $user_categories = getUserCategories($_SESSION['user_id']);
        $valid_categories = array_column($user_categories, 'name');
        if (!in_array($category, $valid_categories)) {
            $error = 'Kategori tidak valid';
        } else {
            try {
                $stmt = $pdo->prepare("INSERT INTO contacts (user_id, name, email, phone, status, category, notes) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$_SESSION['user_id'], $name, $email, $phone, $status, $category, $notes]);
                
                $success = 'Kontak berhasil ditambahkan!';
                
                header('refresh: 2; url=dashboard.php');
            } catch (PDOException $e) {
                $error = 'Terjadi kesalahan saat menyimpan data';
            }
        }
    }
}

$current_user = getCurrentUser();
$user_categories = getUserCategories($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Kontak - Contact Book</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="dashboard-body">
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-person-rolodex"></i>Contact Book
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="add_contact.php">
                            <i class="bi bi-person-plus"></i> Tambah Kontak
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_categories.php">
                            <i class="bi bi-tags"></i> Kelola Kategori
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle"></i> <?= htmlspecialchars($current_user['username'] ?? 'User') ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container main-content">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="contact-form">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h2><i class="bi bi-person-plus"></i> Tambah Kontak Baru</h2>
                        <a href="dashboard.php" class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-left"></i> Kembali
                        </a>
                    </div>

                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-custom"><?= $error ?></div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert alert-success alert-custom">
                            <?= $success ?>
                            <div class="mt-2">
                                <small>Akan dialihkan ke dashboard dalam 2 detik...</small>
                            </div>
                        </div>
                    <?php endif; ?>

                    <form method="POST" novalidate>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name" class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="name" name="name" 
                                           value="<?= isset($_POST['name']) ? htmlspecialchars($_POST['name']) : '' ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone" class="form-label">Nomor Telepon</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" 
                                           value="<?= isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : '' ?>" 
                                           placeholder="Contoh: 081234567890">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="category" class="form-label">Kategori <span class="text-danger">*</span></label>
                                    <div class="d-flex gap-2">
                                        <select class="form-select" id="category" name="category" required>
                                            <option value="">Pilih kategori</option>
                                            <?php foreach ($user_categories as $cat): ?>
                                                <option value="<?= htmlspecialchars($cat['name']) ?>" 
                                                        <?= (isset($_POST['category']) && $_POST['category'] === $cat['name']) ? 'selected' : '' ?>>
                                                    <?= htmlspecialchars($cat['name']) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <a href="manage_categories.php" class="btn btn-outline-primary" title="Kelola Kategori">
                                            <i class="bi bi-gear"></i>
                                        </a>
                                    </div>
                                    <?php if (empty($user_categories)): ?>
                                        <small class="text-muted">
                                            <i class="bi bi-info-circle"></i> Belum ada kategori. 
                                            <a href="manage_categories.php">Tambah kategori</a> terlebih dahulu.
                                        </small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="status" class="form-label">Status</label>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="status" id="status_aktif" value="Aktif" 
                                               <?= (!isset($_POST['status']) || $_POST['status'] === 'Aktif') ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="status_aktif">
                                            <span class="badge bg-success">Aktif</span>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="status" id="status_pasif" value="Pasif"
                                               <?= (isset($_POST['status']) && $_POST['status'] === 'Pasif') ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="status_pasif">
                                            <span class="badge bg-secondary">Pasif</span>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="status" id="status_diblokir" value="Diblokir"
                                               <?= (isset($_POST['status']) && $_POST['status'] === 'Diblokir') ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="status_diblokir">
                                            <span class="badge bg-danger">Diblokir</span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="notes" class="form-label">Catatan</label>
                            <textarea class="form-control" id="notes" name="notes" rows="4" 
                                      placeholder="Tambahkan catatan untuk kontak ini..."><?= isset($_POST['notes']) ? htmlspecialchars($_POST['notes']) : '' ?></textarea>
                        </div>

                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <a href="dashboard.php" class="btn btn-outline-secondary me-md-2">
                                <i class="bi bi-x-circle"></i> Batal
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-check-circle"></i> Simpan Kontak
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html> 