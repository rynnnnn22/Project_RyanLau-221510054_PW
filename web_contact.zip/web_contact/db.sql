CREATE DATABASE IF NOT EXISTS contact_book;
USE contact_book;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(50) NOT NULL,
    color VARCHAR(7) DEFAULT '#6c757d',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_category (user_id, name)
);

CREATE TABLE contacts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(20),
    status ENUM('Aktif', 'Pasif', 'Diblokir') DEFAULT 'Aktif',
    category VARCHAR(50) NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

INSERT INTO users (username, email, password) VALUES
('admin', 'admin@example.com', '$2y$10$KqYXSGpvNQn.ZTvdWUJsIuXgXxJvhypkl7ad84HncnxOAT3RY2IzO'),
('user1', 'user1@example.com', '$2y$10$KqYXSGpvNQn.ZTvdWUJsIuXgXxJvhypkl7ad84HncnxOAT3RY2IzO');

INSERT INTO categories (user_id, name, color) VALUES
(1, 'Klien', '#007bff'),
(1, 'Tim Support', '#17a2b8'),
(1, 'Vendor', '#ffc107'),
(1, 'Partner', '#28a745'),
(2, 'Klien', '#007bff'),
(2, 'Tim Support', '#17a2b8'),
(2, 'Vendor', '#ffc107');

INSERT INTO contacts (user_id, name, email, phone, status, category, notes) VALUES
(1, 'John Doe', 'john@example.com', '081234567890', 'Aktif', 'Klien', 'Klien utama perusahaan ABC'),
(1, 'Jane Smith', 'jane@support.com', '081234567891', 'Aktif', 'Tim Support', 'Tim support aplikasi'),
(1, 'Bob Wilson', 'bob@vendor.com', '081234567892', 'Pasif', 'Vendor', 'Vendor peralatan kantor'),
(1, 'Alice Brown', 'alice@client.com', '081234567893', 'Diblokir', 'Klien', 'Klien bermasalah'),
(1, 'David Parker', 'david@partner.com', '081234567895', 'Aktif', 'Partner', 'Partner bisnis strategis'),
(2, 'Mike Johnson', 'mike@example.com', '081234567894', 'Aktif', 'Klien', 'Klien baru'); 