# Contact Book - Website Manajemen Kontak

Website manajemen daftar kontak sederhana dengan PHP native, MySQL, dan Bootstrap 5.

## 🚀 Fitur Utama

- **Autentikasi User**: Login dan registrasi dengan validasi
- **Manajemen Kontak**: CRUD (Create, Read, Update, Delete) kontak
- **Pencarian & Filter**: Cari berdasarkan nama, email, telepon dengan filter kategori dan status
- **Kategori Kontak**: Klien, Tim Support, Vendor
- **Status Kontak**: Aktif, Pasif, Diblokir dengan badge berwarna
- **Dashboard Statistik**: Jumlah kontak per status
- **Desain Responsif**: Menggunakan Bootstrap 5
- **Validasi Form**: Client-side dan server-side validation

## 📋 Teknologi

- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap 5
- **Backend**: PHP 7.4+
- **Database**: MySQL 5.7+
- **Icons**: Bootstrap Icons
- **Font**: Work Sans

## 🛠️ Instalasi

### 1. Persiapan XAMPP
- Download dan install XAMPP
- Jalankan Apache dan MySQL di XAMPP Control Panel

### 2. Setup Database
- Buka phpMyAdmin (http://localhost/phpmyadmin)
- Import file `db.sql` atau jalankan query berikut:

```sql
CREATE DATABASE IF NOT EXISTS contact_book;
USE contact_book;

-- Tabel users
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel contacts
CREATE TABLE contacts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(20),
    status ENUM('Aktif', 'Pasif', 'Diblokir') DEFAULT 'Aktif',
    category ENUM('Klien', 'Tim Support', 'Vendor') NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

### 3. Setup Project
- Copy folder project ke `xampp/htdocs/web_contact`
- Pastikan struktur folder seperti ini:
```
web_contact/
├── assets/
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── main.js
├── includes/
│   └── config.php
├── welcome.php
├── login.php
├── register.php
├── dashboard.php
├── add_contact.php
├── edit_contact.php
├── delete_contact.php
├── logout.php
└── db.sql
```

### 4. Konfigurasi Database
Edit file `includes/config.php` jika perlu sesuaikan setting database:
```php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'contact_book';
```

## 🌐 Akses Website

1. Buka browser dan akses: `http://localhost/web_contact/welcome.php`
2. Buat akun baru atau gunakan demo account:
   - Username: `admin`
   - Password: `password`

## 📱 Cara Penggunaan

### 1. Registrasi/Login
- Klik "Daftar" untuk membuat akun baru
- Atau klik "Login" untuk masuk dengan akun yang sudah ada

### 2. Dashboard
- Lihat statistik kontak di bagian atas
- Gunakan pencarian untuk mencari kontak
- Filter berdasarkan status atau kategori
- Tabel menampilkan semua kontak dengan aksi edit/hapus

### 3. Tambah Kontak
- Klik tombol "Tambah Kontak"
- Isi form dengan data kontak
- Pilih kategori dan status
- Klik "Simpan Kontak"

### 4. Edit Kontak
- Klik ikon pensil di tabel kontak
- Edit data yang diperlukan
- Klik "Perbarui Kontak"

### 5. Hapus Kontak
- Klik ikon sampah di tabel kontak
- Konfirmasi penghapusan

## 🎨 Struktur Database

### Tabel `users`
- `id`: Primary key
- `username`: Username unik
- `email`: Email unik
- `password`: Password ter-hash
- `created_at`: Timestamp pembuatan

### Tabel `contacts`
- `id`: Primary key
- `user_id`: Foreign key ke tabel users
- `name`: Nama kontak (required)
- `email`: Email kontak
- `phone`: Nomor telepon
- `status`: Aktif/Pasif/Diblokir
- `category`: Klien/Tim Support/Vendor (required)
- `notes`: Catatan tambahan
- `created_at`: Timestamp pembuatan

## 🔒 Keamanan

- Password di-hash menggunakan `password_hash()`
- Prepared statements untuk mencegah SQL injection
- Session management untuk autentikasi
- Input sanitization dan validation
- CSRF protection dengan session checking

## 📞 Support

Jika ada masalah:
1. Pastikan XAMPP Apache dan MySQL berjalan
2. Cek konfigurasi database di `includes/config.php`
3. Pastikan database `contact_book` sudah dibuat
4. Cek permission folder project

## 📄 License

Project ini dibuat untuk keperluan pembelajaran dan dapat digunakan secara bebas. 